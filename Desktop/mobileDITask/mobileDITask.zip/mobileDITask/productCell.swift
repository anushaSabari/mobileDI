//
//  productCell.swift
//  mobileDITask
//
//  Created by anusha sabari on 1/24/18.
//  Copyright © 2018 sabarianusabari. All rights reserved.
//

import UIKit

class productCell: UICollectionViewCell {
    
    @IBOutlet weak var productLabel: UILabel!
    @IBOutlet weak var productImage: UIImageView!
}
